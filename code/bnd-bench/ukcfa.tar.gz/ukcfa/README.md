kcfa
=====

Simple k-CFA implementation


Notes
-----

Original code: <http://matt.might.net/articles/implementation-of-kcfa-and-0cfa/>

Original benchmark: <https://github.com/nuprl/gradual-typing-performance>

Differences from [POPL 2016]:

- `main.rkt` uses smaller lambda calculus term as input
